var GlWrapper = Java.type("com.github.tartaricacid.touhoulittlemaid.client.animation.script.GlWrapper");

Java.asJSONCompatible({
    animation: function (maid, limbSwing, limbSwingAmount, ageInTicks,
        netHeadYaw, headPitch, scale, modelMap) {
        var legLeft = modelMap.get("legLeft");
        var legRight = modelMap.get("legRight");
        var body = modelMap.get("body");

        if (legLeft == undefined || legRight == undefined) {
            return;
        }

        var movement = Math.min(1.0, Math.max(0.0, limbSwingAmount));
        var phase = limbSwing * 0.6662;

        // Match the clearly readable stride of Minecraft's full-size player
        // model. TLM's default maid gait only uses a 0.3-radian multiplier,
        // which is almost invisible on these 32-pixel-tall operator models.
        if (!maid.isSitting() && !maid.isSleep()) {
            legLeft.setRotateAngleX(legLeft.getInitRotateAngleX()
                + Math.cos(phase) * 1.4 * movement);
            legRight.setRotateAngleX(legRight.getInitRotateAngleX()
                - Math.cos(phase) * 1.4 * movement);

            if (body != undefined) {
                body.setRotateAngleX(body.getInitRotateAngleX() + 0.035 * movement);
                body.setRotateAngleZ(body.getInitRotateAngleZ()
                    + Math.cos(phase * 0.5) * 0.025 * movement);
            }

            // A restrained step bounce keeps the model grounded while making
            // movement readable at normal camera distance.
            GlWrapper.translate(0,
                Math.abs(Math.sin(phase)) * 0.045 * movement, 0);
        } else {
            legLeft.setRotateAngleX(legLeft.getInitRotateAngleX());
            legRight.setRotateAngleX(legRight.getInitRotateAngleX());
            if (body != undefined) {
                body.setRotateAngleX(body.getInitRotateAngleX());
                body.setRotateAngleZ(body.getInitRotateAngleZ());
            }
        }
    }
})
